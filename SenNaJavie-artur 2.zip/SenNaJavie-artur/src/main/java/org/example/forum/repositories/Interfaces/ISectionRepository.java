package org.example.forum.repositories.Interfaces;

public interface ISectionRepository {
}
