package org.example.forum.repositories;

import org.example.forum.repositories.Interfaces.IReportRepository;
import org.springframework.stereotype.Repository;

@Repository
public class ReportRepository implements IReportRepository {
}
