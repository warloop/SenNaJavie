package org.example.forum.repositories;

import org.example.forum.repositories.Interfaces.ISectionRepository;
import org.springframework.stereotype.Repository;

@Repository
public class SectionRepository implements ISectionRepository {
}
