package org.example.forum.services.interfaces;

public interface ICommentService {
}
